import { Restaurant, YossiRestaurant } from '../Components/Intefaces/IRestaurant';
import Mashya from '../assets/Cards/yossiRes1.png';
import Kitchen from '../assets/Cards/yossiRes2.png';
import Onza from '../assets/Cards/yossiRes3.png';



export const YossiRestaurants:YossiRestaurant[]=[
    {
        name:'Onza',
        imag:Onza,

    },
    {
        name:'Kitchen Market',
        imag:Kitchen
    },
    {
        name:'Mashya',
        imag:Mashya
    },
      
    
]
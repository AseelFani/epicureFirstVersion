import * as React from 'react';
import {BrowserRouter,Routes ,Route} from "react-router-dom";
import {Footer} from './Components/Footer/Footer';
import Header from './Components/Header/Header';
import Restaurant from './Components/Slider/SliderOfAllRestaurants/RestaurantSlider';
import AllChefsMobile from './Pages/AllChefs/AllChefsMobile';
import AllDishesMobile from './Pages/AllDishes/AllDishesMobile';
import AllRestaurantsMobile from './Pages/AllRestaurants/AllRestaurantsMobile';
import HomePage from './Pages/homePage/homePage';




function App() {
  return (
   <><Header/>
   <BrowserRouter>
    <Routes>
        <Route path="/" element={<HomePage/>}/>
        <Route path='/Restaurant' element={<Restaurant/>} />
        <Route path='/AllRestaurantsMobile' element={<AllRestaurantsMobile/>} />
        <Route path='/AllChefsMobile' element={<AllChefsMobile/>} />
        <Route path='/AllDishesMobile' element={<AllDishesMobile/>} />
    </Routes>
  </BrowserRouter>
    <Footer />
    </>
  );
}


export default App;

export interface IProps {
    open: boolean
    setOpen: (open: boolean) => void

  }
  
export interface IDish{
    name:string;
    description:string;
    imag:string;
    signature?:string;
    price?:string;
}

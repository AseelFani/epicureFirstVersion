export interface IChef{
    name:string;
    imag:string;
}

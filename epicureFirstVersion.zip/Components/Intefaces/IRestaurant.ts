export interface Restaurant{
    name:string;
    chef:string;
    imag:string;
    openNow?:string;
    rating:string;
}
export interface YossiRestaurant{
    name:string;
    imag:string;
}
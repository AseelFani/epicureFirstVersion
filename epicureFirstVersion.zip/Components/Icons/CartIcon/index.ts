
export { default } from './CartIcon'
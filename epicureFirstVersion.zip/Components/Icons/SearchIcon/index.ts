
export { default } from './SearchIcon'
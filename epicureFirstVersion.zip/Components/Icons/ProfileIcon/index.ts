
export { default } from './ProfileIcon'
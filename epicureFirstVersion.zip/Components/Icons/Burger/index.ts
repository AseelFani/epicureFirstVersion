
export { default } from './Burger'